export const colors = {
    black: "#000000",
    green: "#117a37",
    white: "#ffffff",
    grey: "#919496",
    blue: "#2941AB",
    lightGreen: "#1ED760"
}